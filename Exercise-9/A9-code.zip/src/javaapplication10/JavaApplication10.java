/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication10;
import java.sql.*;

/**
 *
 * @author Harshini
 */
public class JavaApplication10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Connection conn=null;
        try{
            String driverName="oracle.jdbc.driver.OracleDriver";
            Class.forName(driverName);
            conn=DriverManager.getConnection("jdbc:oracle:thin:@DESKTOP-N6BHVVF:1521:XE", "harshu", "harshu123");
        }
        catch (ClassNotFoundException e)
        {
            System.out.println("could not find conn db driver"+e.getMessage());
        }
        catch(SQLException e)
        {
            System.out.println("could not connect to db"+e.getMessage());
        }
        
        
}
    
    
}

