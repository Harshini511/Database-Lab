--*****************************************************
--CS 2258                               B.Senthil Kumar
--DBMS Lab				Asst. Prof
--	    		    Computer Science Department
--            		     SSN College of Engineering 
--	                   	     senthil@ssn.edu.in
--*****************************************************
-- 	          AIRLINES DATASET
--                 Version 1.0
--                February 05, 2013
--*****************************************************
--Sources:
--         To create airlines database run the following
--	two script files which will create and populate
-- 	the databases.
--
--******************************************************
-- run the SQL script files

@air_cre.sql
@air_pop.sql

--**********END OF AIRLINES DB CREATION*****************